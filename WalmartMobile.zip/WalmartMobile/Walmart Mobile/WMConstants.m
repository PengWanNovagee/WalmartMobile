//
//  WMConstants.m
//  Walmart Mobile
//
//  Created by Wan, peng on 11/10/15.
//  Copyright © 2015 Wan, peng. All rights reserved.
//

#import "WMConstants.h"

NSString *const WMCollectionViewCellIdentifier = @"CellID";
NSString *const WMTableViewLoadingCellIdentifier = @"LoadingCell";
NSString *const WMTableViewDefaultCellIdentifier = @"defaultCell";
NSString *const WMAPIKeyProductName = @"productName";
NSString *const WMAPIKeyPrice = @"price";
NSString *const WMAPIKeyRating = @"reviewRating";
NSString *const WMAPIKeyCount = @"reviewCount";
NSString *const WMAPIKeyInStock = @"inStock";
NSString *const WMAPIKeyProductImage = @"productImage";
NSString *const WMAPIKeyImageFile= @"imageFile";
NSString *const WMAPIKeyProduct= @"products";
NSString *const WMAPIKeyPageNumber= @"pageNumber";
NSString *const WMAPIKeyTotalProducts= @"totalProducts";
NSString *const WMKeyProductList= @"productList";
NSString *const WMKeyProductDetail= @"productDetail";
NSString *const WMAPIKeySHortDescription= @"shortDescription";
NSString *const WMAPIKeyLongDescription= @"longDescription";

