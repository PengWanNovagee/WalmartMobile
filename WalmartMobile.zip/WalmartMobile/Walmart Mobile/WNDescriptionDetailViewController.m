//
//  WNDescriptionDetailViewController.m
//  Walmart Mobile
//
//  Created by Wan, peng on 11/9/15.
//  Copyright © 2015 Wan, peng. All rights reserved.
//

#import "WNDescriptionDetailViewController.h"

@interface WNDescriptionDetailViewController ()
@property (weak, nonatomic) IBOutlet UITextView *descriptionTextView;
@property (weak, nonatomic) IBOutlet UITextView *scrollView;

@end

@implementation WNDescriptionDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.descriptionTextView.attributedText = self.descriptionString;
}

@end
