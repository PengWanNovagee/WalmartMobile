//
//  WMConstants.h
//  Walmart Mobile
//
//  Created by Wan, peng on 11/10/15.
//  Copyright © 2015 Wan, peng. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSString *const WMCollectionViewCellIdentifier;
extern NSString *const WMTableViewLoadingCellIdentifier;
extern NSString *const WMTableViewDefaultCellIdentifier;
extern NSString *const WMAPIKeyProductName;
extern NSString *const WMAPIKeyPrice;
extern NSString *const WMAPIKeyRating;
extern NSString *const WMAPIKeyCount;
extern NSString *const WMAPIKeyInStock;
extern NSString *const WMAPIKeyProductImage;
extern NSString *const WMAPIKeyImageFile;
extern NSString *const WMAPIKeyProduct;
extern NSString *const WMAPIKeyPageNumber;
extern NSString *const WMAPIKeyTotalProducts;
extern NSString *const WMKeyProductList;
extern NSString *const WMKeyProductDetail;
extern NSString *const WMAPIKeySHortDescription;
extern NSString *const WMAPIKeyLongDescription;