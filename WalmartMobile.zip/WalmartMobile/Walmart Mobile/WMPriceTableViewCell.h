//
//  WMPriceTableViewCell.h
//  Walmart Mobile
//
//  Created by Wan, peng on 11/8/15.
//  Copyright © 2015 Wan, peng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "StarRatingView.h"

@interface WMPriceTableViewCell : UITableViewCell

@property (nonatomic, weak) IBOutlet UILabel *priceLabel;
@property (nonatomic, weak) IBOutlet StarRatingView *ratingView;
@property (nonatomic, weak) IBOutlet UILabel *inStockLabel;

- (void)setupRatingViewWithRating:(NSInteger)rating andCount:(NSInteger)count;

@end
