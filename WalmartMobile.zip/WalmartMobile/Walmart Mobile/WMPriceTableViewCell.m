//
//  WMPriceTableViewCell.m
//  Walmart Mobile
//
//  Created by Wan, peng on 11/8/15.
//  Copyright © 2015 Wan, peng. All rights reserved.
//

#import "WMPriceTableViewCell.h"

#define kLabelAllowance 50.0f
#define kStarViewHeight 8.0f
#define kStarViewWidth 43.0f
#define kLeftPadding 5.0f

@interface WMPriceTableViewCell ()

@property (assign, nonatomic) BOOL isRatingSet;

@end

@implementation WMPriceTableViewCell

- (void)awakeFromNib {
    // Initialization code
    self.isRatingSet = NO;
}

- (void)setupRatingViewWithRating:(NSInteger)rating andCount:(NSInteger)count
{
    if (!self.isRatingSet) {
        [self.ratingView setupUIWithFrame:CGRectMake(8, 70, kStarViewWidth+kLabelAllowance+kLeftPadding, kStarViewHeight) andRating:rating withCount:count animated:YES];
        self.isRatingSet = YES;
    } else {
        [self.ratingView setRating:rating withCount:count];
    }
}


@end
