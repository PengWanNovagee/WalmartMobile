//
//  WMProductNameTableViewCell.m
//  Walmart Mobile
//
//  Created by Wan, peng on 11/9/15.
//  Copyright © 2015 Wan, peng. All rights reserved.
//

#import "WMProductNameTableViewCell.h"

static const CGFloat DESCRIPTION_LABEL_PADDING = 10.0f;

@implementation WMProductNameTableViewCell

- (CGFloat)heightForCellWithDescription:(NSString *)description
{
    self.productNameLabel.text = description;
    [self.productNameLabel sizeToFit];
    return CGRectGetHeight(self.productNameLabel.frame) + DESCRIPTION_LABEL_PADDING;
}

@end
