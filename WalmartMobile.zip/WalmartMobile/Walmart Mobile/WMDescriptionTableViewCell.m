//
//  WMDescriptionTableViewCell.m
//  Walmart Mobile
//
//  Created by Wan, peng on 11/8/15.
//  Copyright © 2015 Wan, peng. All rights reserved.
//

#import "WMDescriptionTableViewCell.h"

static const CGFloat DESCRIPTION_LABEL_PADDING = 8.0f;

@implementation WMDescriptionTableViewCell

- (void)awakeFromNib {
    // Initialization code
    self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    self.selectionStyle = UITableViewCellSelectionStyleNone;
}

- (CGFloat)heightForCellWithDescription:(NSAttributedString *)description
{
    self.descriptionLabel.attributedText = description;
    [self.descriptionLabel sizeToFit];
    NSLog(@"height:%f",CGRectGetHeight(self.descriptionLabel.frame));
    return CGRectGetHeight(self.descriptionLabel.frame) + DESCRIPTION_LABEL_PADDING;
}

@end
