//
//  StarRatingView.h
//  Walmart Mobile
//
//  Created by Wan, peng on 11/6/15.
//  Copyright © 2015 Wan, peng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StarRatingView : UIView

- (void)setupUIWithFrame:(CGRect)frame andRating:(NSInteger)rating withCount:(NSInteger)count animated:(BOOL)animated;
- (void)setRating:(NSInteger)rating withCount:(NSInteger)count;
@end