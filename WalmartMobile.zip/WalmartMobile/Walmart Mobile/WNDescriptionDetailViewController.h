//
//  WNDescriptionDetailViewController.h
//  Walmart Mobile
//
//  Created by Wan, peng on 11/9/15.
//  Copyright © 2015 Wan, peng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WNDescriptionDetailViewController : UIViewController

@property (copy, nonatomic) NSAttributedString *descriptionString;

@end
