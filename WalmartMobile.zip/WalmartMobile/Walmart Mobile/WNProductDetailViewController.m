//
//  WNProductDetailViewController.m
//  Walmart Mobile
//
//  Created by Wan, peng on 11/7/15.
//  Copyright © 2015 Wan, peng. All rights reserved.
//

#import "WNProductDetailViewController.h"
#import "WMNetworkUtility.h"
#import "ParallaxHeaderView.h"
#import "WMPriceTableViewCell.h"
#import "WMDescriptionTableViewCell.h"
#import "WNDescriptionDetailViewController.h"
#import "WMProductNameTableViewCell.h"
#import "MBProgressHUD.h"
#import "UIImage+ImageEffects.h"
#import "WMConstants.h"

@interface WNProductDetailViewController ()

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (strong, nonatomic) NSDictionary *productDetailDict;
@property (nonatomic, strong) NSURLSession *session;
@property (nonatomic, strong) ParallaxHeaderView *headerView;
@property (nonatomic, strong) UIView *helperView;

@end

@implementation WNProductDetailViewController

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {

        NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
        _session = [NSURLSession sessionWithConfiguration:config];

        UILabel *titleLable = [[UILabel alloc] initWithFrame:CGRectMake(0,0,32,32)];
        titleLable.text = @"Product Details";
        titleLable.font = [UIFont fontWithName:@"Helvetica-Bold" size:20];
        titleLable.textColor = [UIColor whiteColor];
        self.navigationItem.titleView = titleLable;

    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupUI];
    [self drawHelperView];
}

- (void)viewDidAppear:(BOOL)animated
{
    [(ParallaxHeaderView *)self.tableView.tableHeaderView refreshBlurViewForNewImage];
    [super viewDidAppear:animated];
}

#pragma mark -
#pragma mark UISCrollViewDelegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (scrollView == self.tableView)
    {
        // pass the current offset of the UITableView so that the ParallaxHeaderView layouts the subViews.
        [(ParallaxHeaderView *)self.tableView.tableHeaderView layoutHeaderViewForScrollViewOffset:scrollView.contentOffset];
    }
}

#pragma mark -
#pragma mark Custom Methods

-(void)handleLeftSwipeFrom:(UISwipeGestureRecognizer *)recognizer {

    if (self.index < [[[WMNetworkUtility sharedInstance] currentProductArray] count] -1 ) {
        [self setupUIFromProductDict:[[[WMNetworkUtility sharedInstance] currentProductArray] objectAtIndex:++self.index]];
    }
}

-(void)handleRightSwipeFrom:(UISwipeGestureRecognizer *)recognizer {

    if (self.index >0) {
        [self setupUIFromProductDict:[[[WMNetworkUtility sharedInstance] currentProductArray] objectAtIndex:--self.index]];
    }
}

- (void)setupUIFromProductDict:(NSDictionary *)dict {

    self.productDetailDict = dict;
    [self setupParallaxHeader];
    [self.tableView reloadData];
}

- (void)setupUI
{
    self.tableView.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);
    UISwipeGestureRecognizer *recognizer = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleLeftSwipeFrom:)];
    recognizer.direction = UISwipeGestureRecognizerDirectionLeft;
    [self.tableView addGestureRecognizer:recognizer];

    [self.navigationController.navigationBar setTintColor:[UIColor whiteColor]];

    UISwipeGestureRecognizer *recognizerRight = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleRightSwipeFrom:)];
    recognizerRight.direction = UISwipeGestureRecognizerDirectionRight;
    [self.tableView addGestureRecognizer:recognizerRight];
    self.productDetailDict = [[[WMNetworkUtility sharedInstance] currentProductArray] objectAtIndex:self.index];

    [self.tableView registerNib:[UINib nibWithNibName:NSStringFromClass([WMPriceTableViewCell class]) bundle:nil] forCellReuseIdentifier:NSStringFromClass([WMPriceTableViewCell class])];
    [self.tableView registerNib:[UINib nibWithNibName:NSStringFromClass([WMDescriptionTableViewCell class]) bundle:nil] forCellReuseIdentifier:NSStringFromClass([WMDescriptionTableViewCell class])];
    [self.tableView registerNib:[UINib nibWithNibName:NSStringFromClass([WMProductNameTableViewCell class]) bundle:nil] forCellReuseIdentifier:NSStringFromClass([WMProductNameTableViewCell class])];
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(dismiss:)];
        self.headerView = [ParallaxHeaderView parallaxHeaderViewWithImage:[self.productDetailDict objectForKey:WMAPIKeyImageFile] forSize:CGSizeMake(self.tableView.frame.size.width, 500)];
        self.headerView.headerTitleLabel.text = @"";
        [self.tableView setTableHeaderView:self.headerView];
    } else {
        self.headerView = [ParallaxHeaderView parallaxHeaderViewWithImage:[self.productDetailDict objectForKey:WMAPIKeyImageFile] forSize:CGSizeMake(self.tableView.frame.size.width, 240)];
        self.headerView.headerTitleLabel.text = @"";
        [self.tableView setTableHeaderView:self.headerView];
    }
}

- (void)drawHelperView
{
    if (![[NSUserDefaults standardUserDefaults] boolForKey:WMKeyProductDetail]) {
        self.helperView = [[UIView alloc] initWithFrame:self.navigationController.view.frame];
        self.helperView.backgroundColor = [UIColor colorWithWhite:0.5 alpha:0.8];

        UILabel *scrollLabel = [[UILabel alloc]initWithFrame:CGRectMake((self.helperView.frame.size.width - 200)/2, 40, 300, 20)];
        scrollLabel.text = @"----Scroll up and down----";
        scrollLabel.textColor = [UIColor whiteColor];
        scrollLabel.font = [UIFont boldSystemFontOfSize:20];
        [self.helperView addSubview:scrollLabel];

        UILabel *rightLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.helperView.frame.size.width - 150, self.helperView.frame.size.height/2, 150, 20)];
        rightLabel.text = @"-> Swipe right";
        rightLabel.textColor = [UIColor whiteColor];
        rightLabel.font = [UIFont boldSystemFontOfSize:20];
        [self.helperView addSubview:rightLabel];

        UILabel *leftLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, self.helperView.frame.size.height/2, 150, 20)];
        leftLabel.text = @"<- Swipe left";
        leftLabel.textColor = [UIColor whiteColor];
        leftLabel.font = [UIFont boldSystemFontOfSize:20];
        [self.helperView addSubview:leftLabel];

        UIButton *touchButton = [[UIButton alloc] initWithFrame:self.helperView.frame];
        [touchButton addTarget:self action:@selector(removeHelperView) forControlEvents:UIControlEventTouchUpInside];
        [self.helperView addSubview:touchButton];

        [self.navigationController.view addSubview:self.helperView];
    }
}

- (void) removeHelperView
{
    [self.helperView removeFromSuperview];
    [[NSUserDefaults standardUserDefaults] setValue:@YES forKey:WMKeyProductDetail];
}

- (void)dismiss:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)setupParallaxHeader
{
    __weak __typeof(self) weakSelf = self;
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD showHUDAddedTo:weakSelf.navigationController.view animated:YES];
    });

    if ([self.productDetailDict objectForKey:WMAPIKeyImageFile]) {

        [self.headerView setHeaderImage:[self.productDetailDict objectForKey:WMAPIKeyImageFile]];
        self.headerView.bluredImageView.image =                                 self.headerView.bluredImageView.image = [[self.productDetailDict objectForKey:WMAPIKeyImageFile] applyBlurWithRadius:5 tintColor:[UIColor colorWithWhite:0.6 alpha:0.2] saturationDeltaFactor:1.0 maskImage:nil];

        dispatch_async(dispatch_get_main_queue(), ^{
            [MBProgressHUD hideAllHUDsForView:weakSelf.navigationController.view animated:NO];
        });

    } else {
        NSURLSessionDownloadTask *getImageTask =
        [self.session downloadTaskWithURL:[NSURL URLWithString:[self.productDetailDict objectForKey:WMAPIKeyProductImage]]

                        completionHandler:^(NSURL *location,
                                            NSURLResponse *response,
                                            NSError *error) {
                            UIImage *downloadedImage =
                            [UIImage imageWithData:
                             [NSData dataWithContentsOfURL:location]];
                            dispatch_async(dispatch_get_main_queue(), ^{
                                // do stuff with image
                                [weakSelf.headerView setHeaderImage:downloadedImage];
                                weakSelf.headerView.bluredImageView.image = [downloadedImage applyBlurWithRadius:5 tintColor:[UIColor colorWithWhite:0.6 alpha:0.2] saturationDeltaFactor:1.0 maskImage:nil];

                                dispatch_async(dispatch_get_main_queue(), ^{
                                    [MBProgressHUD hideAllHUDsForView:weakSelf.navigationController.view animated:NO];
                                });

                            });
                        }];

        [getImageTask resume];

    }
}

#pragma mark -
#pragma mark UITableViewDatasource

- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    switch (section) {
        case 0:
            return 2;
            break;

            case 1:
            return 1;
            break;

        default:
            return 0;
            break;
    }
}

- (CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.section) {
        case 0:
        {
            switch (indexPath.row) {
                case 0:
                {

                    WMProductNameTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([WMProductNameTableViewCell class])];
                    return [cell heightForCellWithDescription:self.productDetailDict[WMAPIKeyProductName]];

                }
                    break;
                case 1:
                    return 66;
                    break;

                default:
                    return 44;
                    break;
            }
        }
            break;

        case 1: {
            WMDescriptionTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([WMDescriptionTableViewCell class])];

            NSAttributedString *attr = [[NSAttributedString alloc] initWithData:[self.productDetailDict[WMAPIKeySHortDescription] dataUsingEncoding:NSUTF8StringEncoding]
                                                                        options:@{NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType,
                                                                                  NSCharacterEncodingDocumentAttribute:@(NSUTF8StringEncoding)}
                                                             documentAttributes:nil
                                                                          error:nil];
            if (attr) {
                return [cell heightForCellWithDescription:attr];
            } else {
                return 44;
            }

        }
            break;
            
        default:
            return 44;
            break;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section;
{
    switch (section) {
        case 0:
            return 0;
            break;

        case 1:
            return 10;

        default:
            return 0;
            break;
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.section) {
        case 0: {
            switch (indexPath.row) {
                case 0: {
                    WMProductNameTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([WMProductNameTableViewCell class]) forIndexPath:indexPath];
                    cell.productNameLabel.text = self.productDetailDict[WMAPIKeyProductName];
                    return cell;
                }
                    break;
                case 1: {
                    WMPriceTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([WMPriceTableViewCell class]) forIndexPath:indexPath];
                    [cell setupRatingViewWithRating:[self.productDetailDict[WMAPIKeyRating] intValue] andCount:[self.productDetailDict[WMAPIKeyCount] intValue]];
                    cell.priceLabel.text = self.productDetailDict[WMAPIKeyPrice];
                    if ([self.productDetailDict[WMAPIKeyInStock] boolValue] == YES) {
                        cell.inStockLabel.text = @"In stock";
                    } else {
                        cell.inStockLabel.text = @"Not in stock";
                    }
                    return cell;

                }
                    break;
                    
                default: {
                    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:WMTableViewDefaultCellIdentifier forIndexPath:indexPath];
                    return cell;

                }
                    break;
            }

        }
            break;

        case 1: {

            WMDescriptionTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([WMDescriptionTableViewCell class]) forIndexPath:indexPath];
            if (self.productDetailDict[@"shortDescription"]) {
                NSAttributedString *attr = [[NSAttributedString alloc] initWithData:[self.productDetailDict[@"shortDescription"] dataUsingEncoding:NSUTF8StringEncoding]
                                                                            options:@{NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType,
                                                                                      NSCharacterEncodingDocumentAttribute:@(NSUTF8StringEncoding)}
                                                                 documentAttributes:nil
                                                                              error:nil];

                cell.descriptionLabel.attributedText = attr;
            } else {
                cell.descriptionLabel.text = @"Detail Descriptions";
            }

            return cell;
        }
            break;

        default:
        {
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:WMTableViewDefaultCellIdentifier forIndexPath:indexPath];
            return cell;
        }
            break;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
{
    if (indexPath.section==1 && indexPath.row==0) {
        [self performSegueWithIdentifier:@"detailDescription" sender:self];
    }
}

#pragma mark - Navigation

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {

    if ([segue.destinationViewController isKindOfClass:[WNDescriptionDetailViewController class]]) {

        WNDescriptionDetailViewController *detailVC = segue.destinationViewController;

        NSAttributedString *attr = [[NSAttributedString alloc] initWithData:[self.productDetailDict[WMAPIKeyLongDescription] dataUsingEncoding:NSUTF8StringEncoding]
                                                                    options:@{NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType,
                                                                              NSCharacterEncodingDocumentAttribute:@(NSUTF8StringEncoding)}
                                                         documentAttributes:nil
                                                                      error:nil];
        detailVC.descriptionString = attr;

    }
}

@end
