//
//  StarRatingView.m
//  Walmart Mobile
//
//  Created by Wan, peng on 11/6/15.
//  Copyright © 2015 Wan, peng. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import "StarRatingView.h"

#define kLeftPadding 5.0f

@interface StarRatingView()

@property (nonatomic) NSInteger userRating;
@property (nonatomic) NSInteger maxrating;
@property (nonatomic) NSInteger rating;
@property (nonatomic) NSInteger count;
@property (nonatomic) BOOL animated;
@property (nonatomic) CGFloat kLabelAllowance;
@property (nonatomic,strong) NSTimer* timer;
@property (nonatomic,strong) UILabel* label;
@property (nonatomic,strong) CALayer* tintLayer;

@end

@implementation StarRatingView

- (id)initWithFrame:(CGRect)frame andRating:(NSInteger)rating withCount:(NSInteger)count animated:(BOOL)animated
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setupUIWithFrame:frame andRating:rating withCount:count animated:animated];
    }
    return self;
}

- (void)setupUIWithFrame:(CGRect)frame andRating:(NSInteger)rating withCount:(NSInteger)count animated:(BOOL)animated
{
    self.opaque = NO;
    _maxrating = rating;
    self.animated = animated;
    self.count = count;

    self.kLabelAllowance = 50.0f;
    self.label = [[UILabel alloc]initWithFrame:CGRectMake(self.bounds.size.width-self.kLabelAllowance - 30, 0,self.kLabelAllowance, frame.size.height)];

    self.label.font = [UIFont systemFontOfSize:8.0f];
    self.label.text = [NSString stringWithFormat:@"(%ld)",(long)self.count];
    self.label.textAlignment = NSTextAlignmentRight;
    self.label.textColor = [UIColor grayColor];
    self.label.backgroundColor = [UIColor clearColor];
    [self addSubview:self.label];

    CGRect newrect = CGRectMake(0, 0, self.bounds.size.width-self.kLabelAllowance, self.bounds.size.height);
    CALayer* starBackground = [CALayer layer];
    starBackground.contents = (__bridge id)([UIImage imageNamed:@"5starsgray"].CGImage);
    starBackground.frame = newrect;
    [self.layer addSublayer:starBackground];

    self.tintLayer = [CALayer layer];
    self.tintLayer.frame = CGRectMake(0, 0, 0, self.bounds.size.height);

    [self.layer addSublayer:self.tintLayer];
    CALayer* starMask = [CALayer layer];
    starMask.contents = (__bridge id)([UIImage imageNamed:@"5starsgray"].CGImage);
    starMask.frame = newrect;
    [self.layer addSublayer:starMask];
    self.tintLayer.mask = starMask;

    if (self.animated) {
        _rating = 0;
        self.timer = [NSTimer scheduledTimerWithTimeInterval:0.01 target:self selector:@selector(increaseRating) userInfo:nil repeats:YES];
        [self performSelector:@selector(ratingDidChange) withObject:nil afterDelay:0.8];
    }else{
        _rating = _maxrating;
    }
}

- (void)setRating:(NSInteger)rating withCount:(NSInteger)count
{
    self.count = count;
    _maxrating = rating;
    self.label.text = [NSString stringWithFormat:@" (%ld)",(long)self.count];
    float barWitdhPercentage = (_maxrating * 1.0f / 5) *  (self.bounds.size.width-self.kLabelAllowance);
    self.tintLayer.frame = CGRectMake(0, 0, barWitdhPercentage, self.frame.size.height);
}

-(void)increaseRating
{
    if (_rating<_maxrating) {
        _rating = _rating + 1;
        if (self.label) {
            self.label.text = [NSString stringWithFormat:@" (%ld)",(long)self.count];
        }
    }else{
        [self.timer invalidate];
    }
}

-(void)ratingDidChange
{
    [self.tintLayer setBackgroundColor:[UIColor colorWithRed:21.0/255.0 green:126.0/255.0 blue:195.0/255.0 alpha:1].CGColor];
    float barWitdhPercentage = (_maxrating * 1.0f / 5) *  (self.bounds.size.width-self.kLabelAllowance);
    self.tintLayer.frame = CGRectMake(0, 0, barWitdhPercentage, self.frame.size.height);
}

@end
