//
//  WMProductCollectionViewCell.h
//  Walmart Mobile
//
//  Created by Wan, peng on 11/7/15.
//  Copyright © 2015 Wan, peng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "StarRatingView.h"

@interface WMProductCollectionViewCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UILabel *label;
@property (weak, nonatomic) IBOutlet UILabel *priceLabel;
@property (weak, nonatomic) IBOutlet UILabel *inStockLabel;
@property (weak, nonatomic) IBOutlet StarRatingView *ratingView;

- (void)setupRatingViewWithRating:(NSInteger)rating andCount:(NSInteger)count;

@end
