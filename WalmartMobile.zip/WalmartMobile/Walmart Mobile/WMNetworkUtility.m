//
//  WMNetworkUtility.m
//  Walmart Mobile
//
//  Created by Wan, peng on 11/6/15.
//  Copyright © 2015 Wan, peng. All rights reserved.
//

#import "WMNetworkUtility.h"

static NSString * const APIKey = @"dd8dd710-bf67-478f-a3d4-384acce3d675";
static NSString * const baseURL = @"https://walmartlabs-test.appspot.com/_ah/api/walmart/v1";
static NSString * const productListURLPath = @"/walmartproducts/";

@implementation WMNetworkUtility

+ (NSURL *)getProductListURLPathForPage:(NSInteger)page
{
    NSString *url = [NSString stringWithFormat:@"%@%@%@/%ld/20",baseURL,productListURLPath,APIKey,(long)page];
    return [NSURL URLWithString:url];
}

+ (instancetype)sharedInstance
{
    static WMNetworkUtility *instance = nil;
    static dispatch_once_t onceToken;

    dispatch_once(&onceToken, ^{
        instance = [WMNetworkUtility new];
    });

    return instance;
}

@end
