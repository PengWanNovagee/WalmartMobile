//
//  WMNetworkUtility.h
//  Walmart Mobile
//
//  Created by Wan, peng on 11/6/15.
//  Copyright © 2015 Wan, peng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WMNetworkUtility : NSObject

+ (instancetype)sharedInstance;
+ (NSURL *)getProductListURLPathForPage:(NSInteger)page;

@property (nonatomic, strong) NSArray *currentProductArray;

@end
