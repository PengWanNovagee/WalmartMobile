//
//  WNProductiPadCollectionViewController.m
//  Walmart Mobile
//
//  Created by Wan, peng on 11/7/15.
//  Copyright © 2015 Wan, peng. All rights reserved.
//

#import "WNProductiPadCollectionViewController.h"
#import "WMProductCollectionViewCell.h"
#import "WMNetworkUtility.h"
#import "WNProductDetailViewController.h"
#import "MBProgressHUD.h"
#import "WMConstants.h"

@interface WNProductiPadCollectionViewController () <UICollectionViewDelegate,UICollectionViewDataSource>

@property (nonatomic, strong) NSURLSession *session;
@property (nonatomic, strong) UIView *refreshLoadingView;
@property (nonatomic, strong) UIView *refreshColorView;
@property (nonatomic, strong) UIImageView *compass_background;
@property (nonatomic, strong) UIImageView *compass_spinner;
@property (nonatomic, strong) UIRefreshControl *refreshControl;
@property (nonatomic, strong) UIView *helperView;
@property (assign) BOOL isRefreshIconsOverlap;
@property (assign) BOOL isRefreshAnimating;
@property (nonatomic, assign) NSInteger currentPage;
@property (nonatomic, assign) NSInteger totalItems;

@end

@implementation WNProductiPadCollectionViewController

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {

        //setup NSURLSession
        NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
        _session = [NSURLSession sessionWithConfiguration:config];

        //set up title view
        UILabel *titleLable = [[UILabel alloc] initWithFrame:CGRectMake(0,0,32,32)];
        titleLable.text = @"Walmart";
        titleLable.font = [UIFont fontWithName:@"Helvetica-Bold" size:20];
        titleLable.textColor = [UIColor whiteColor];
        self.navigationItem.titleView = titleLable;

    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setupRefreshControl];
    [self drawHelperView];
    self.currentPage = 1;
    [self renderProducts:self.currentPage];
}

#pragma mark -
#pragma mark UISCrollViewDelegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    // Get the current size of the refresh controller
    CGRect refreshBounds = self.refreshControl.bounds;

    // Distance the table has been pulled >= 0
    CGFloat pullDistance = MAX(0.0, -self.refreshControl.frame.origin.y);

    // Half the width of the table
    CGFloat midX = self.collectionView.frame.size.width / 2.0;

    // Calculate the width and height of our graphics
    CGFloat compassHeight = self.compass_background.bounds.size.height;
    CGFloat compassHeightHalf = compassHeight / 2.0;

    CGFloat compassWidth = self.compass_background.bounds.size.width;
    CGFloat compassWidthHalf = compassWidth / 2.0;

    CGFloat spinnerHeight = self.compass_spinner.bounds.size.height;
    CGFloat spinnerHeightHalf = spinnerHeight / 2.0;

    CGFloat spinnerWidth = self.compass_spinner.bounds.size.width;
    CGFloat spinnerWidthHalf = spinnerWidth / 2.0;

    // Calculate the pull ratio, between 0.0-1.0
    CGFloat pullRatio = MIN( MAX(pullDistance, 0.0), 100.0) / 100.0;

    // Set the Y coord of the graphics, based on pull distance
    CGFloat compassY = pullDistance / 2.0 - compassHeightHalf;
    CGFloat spinnerY = pullDistance / 2.0 - spinnerHeightHalf;

    // Calculate the X coord of the graphics, adjust based on pull ratio
    CGFloat compassX = (midX + compassWidthHalf) - (compassWidth * pullRatio);
    CGFloat spinnerX = (midX - spinnerWidth - spinnerWidthHalf) + (spinnerWidth * pullRatio);

    // When the compass and spinner overlap, keep them together
    if (fabs(compassX - spinnerX) < 1.0) {
        self.isRefreshIconsOverlap = YES;
    }

    // If the graphics have overlapped or we are refreshing, keep them together
    if (self.isRefreshIconsOverlap || self.refreshControl.isRefreshing) {
        compassX = midX - compassWidthHalf;
        spinnerX = midX - spinnerWidthHalf;
    }

    // Set the graphic's frames
    CGRect compassFrame = self.compass_background.frame;
    compassFrame.origin.x = compassX;
    compassFrame.origin.y = compassY;

    CGRect spinnerFrame = self.compass_spinner.frame;
    spinnerFrame.origin.x = spinnerX;
    spinnerFrame.origin.y = spinnerY;

    self.compass_background.frame = compassFrame;
    self.compass_spinner.frame = spinnerFrame;

    // Set the encompassing view's frames
    refreshBounds.size.height = pullDistance;

    self.refreshColorView.frame = refreshBounds;
    self.refreshLoadingView.frame = refreshBounds;

    // If we're refreshing and the animation is not playing, then play the animation
    if (self.refreshControl.isRefreshing && !self.isRefreshAnimating) {
        [self animateRefreshView];
    }
}

#pragma mark -
#pragma mark Custom Methods

- (void)drawHelperView
{
    if (![[NSUserDefaults standardUserDefaults] boolForKey:@"productList"]) {
        self.helperView = [[UIView alloc] initWithFrame:self.navigationController.view.frame];
        self.helperView.backgroundColor = [UIColor colorWithWhite:0.5 alpha:0.8];

        UILabel *pullToRefresh = [[UILabel alloc]initWithFrame:CGRectMake((self.helperView.frame.size.width - 200)/2, 40, 300, 20)];
        pullToRefresh.text = @"----Pull To Refresh----";
        pullToRefresh.textColor = [UIColor whiteColor];
        pullToRefresh.font = [UIFont boldSystemFontOfSize:20];
        [self.helperView addSubview:pullToRefresh];

        UILabel *productCellLabel = [[UILabel alloc]initWithFrame:CGRectMake((self.helperView.frame.size.width - 300)/2,self.helperView.frame.size.height/2, 400, 20)];
        productCellLabel.text = @"Product card with rating and info";
        productCellLabel.textColor = [UIColor whiteColor];
        productCellLabel.font = [UIFont boldSystemFontOfSize:20];
        [self.helperView addSubview:productCellLabel];

        UILabel *infiniteScrollLagel = [[UILabel alloc]initWithFrame:CGRectMake((self.helperView.frame.size.width - 300)/2,self.helperView.frame.size.height - 40, 300, 20)];
        infiniteScrollLagel.text = @"----Scroll to download more----";
        infiniteScrollLagel.textColor = [UIColor whiteColor];
        infiniteScrollLagel.font = [UIFont boldSystemFontOfSize:20];
        [self.helperView addSubview:infiniteScrollLagel];

        UIButton *touchButton = [[UIButton alloc] initWithFrame:self.helperView.frame];
        [touchButton addTarget:self action:@selector(removeHelperView) forControlEvents:UIControlEventTouchUpInside];
        [self.helperView addSubview:touchButton];
        [self.navigationController.view addSubview:self.helperView];
    }
}

- (void) removeHelperView
{
    [self.helperView removeFromSuperview];
    [[NSUserDefaults standardUserDefaults] setValue:@YES forKey:WMKeyProductList];
}

- (void)setupRefreshControl
{
    self.refreshControl = [[UIRefreshControl alloc] init];
    [self.collectionView addSubview:self.refreshControl];
    self.collectionView.alwaysBounceVertical = YES;
    // Setup the loading view, which will hold the moving graphics
    self.refreshLoadingView = [[UIView alloc] initWithFrame:self.refreshControl.bounds];
    self.refreshLoadingView.backgroundColor = [UIColor clearColor];

    // Setup the color view, which will display the rainbowed background
    self.refreshColorView = [[UIView alloc] initWithFrame:self.refreshControl.bounds];
    self.refreshColorView.backgroundColor = [UIColor clearColor];
    self.refreshColorView.alpha = 0.30;

    // Create the graphic image views
    self.compass_background = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"compass_background.png"]];
    self.compass_spinner = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"compass_spinner.png"]];

    // Add the graphics to the loading view
    [self.refreshLoadingView addSubview:self.compass_background];
    [self.refreshLoadingView addSubview:self.compass_spinner];

    // Clip so the graphics don't stick out
    self.refreshLoadingView.clipsToBounds = YES;

    // Hide the original spinner icon
    self.refreshControl.tintColor = [UIColor clearColor];

    // Add the loading and colors views to our refresh control
    [self.refreshControl addSubview:self.refreshColorView];
    [self.refreshControl addSubview:self.refreshLoadingView];

    // Initalize flags
    self.isRefreshIconsOverlap = NO;
    self.isRefreshAnimating = NO;

    // When activated, invoke our refresh function
    [self.refreshControl addTarget:self action:@selector(refresh:) forControlEvents:UIControlEventValueChanged];
}

- (void)refresh:(id)sender{

    self.currentPage = 1;
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    NSURL *url = [WMNetworkUtility getProductListURLPathForPage:self.currentPage];

    __weak __typeof(self) weakSelf = self;
    NSURLSessionDataTask *dataTask =
    [self.session dataTaskWithURL:url
                completionHandler:^(NSData *data,
                                    NSURLResponse *response,
                                    NSError *error) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [MBProgressHUD hideAllHUDsForView:weakSelf.navigationController.view animated:NO];
                    });
                    if (!error) {

                        NSHTTPURLResponse *httpResp = (NSHTTPURLResponse*) response;
                        if (httpResp.statusCode == 200) {

                            NSError *jsonError;
                            NSDictionary *productJSON =
                            [NSJSONSerialization JSONObjectWithData:data
                                                            options:NSJSONReadingAllowFragments
                                                              error:&jsonError];

                            if (!jsonError) {

                                [[WMNetworkUtility sharedInstance] setCurrentProductArray:productJSON[WMAPIKeyProduct]];
                                self.currentPage = [productJSON[WMAPIKeyPageNumber] integerValue];
                                self.totalItems = [productJSON[WMAPIKeyTotalProducts] integerValue];

                                dispatch_async(dispatch_get_main_queue(), ^{
                                    [weakSelf.collectionView reloadData];
                                });

                                double delayInSeconds = 0.5;
                                dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
                                dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
                                    [weakSelf.refreshControl endRefreshing];
                                });

                            }
                        }

                    }
                }];

    [dataTask resume];
}

- (void)renderProducts:(NSInteger)page
{
    __weak __typeof(self) weakSelf = self;
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD showHUDAddedTo:weakSelf.navigationController.view animated:YES];
    });

    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    NSURL *url = [WMNetworkUtility getProductListURLPathForPage:self.currentPage];

    NSURLSessionDataTask *dataTask =
    [self.session dataTaskWithURL:url
                completionHandler:^(NSData *data,
                                    NSURLResponse *response,
                                    NSError *error) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [MBProgressHUD hideAllHUDsForView:weakSelf.navigationController.view animated:NO];
                    });
                    if (!error) {

                        NSHTTPURLResponse *httpResp = (NSHTTPURLResponse*) response;
                        if (httpResp.statusCode == 200) {

                            NSError *jsonError;
                            NSDictionary *productJSON =
                            [NSJSONSerialization JSONObjectWithData:data
                                                            options:NSJSONReadingAllowFragments
                                                              error:&jsonError];

                            if (!jsonError) {
                                if (![[WMNetworkUtility sharedInstance] currentProductArray]) {
                                    [[WMNetworkUtility sharedInstance] setCurrentProductArray:productJSON[WMAPIKeyProduct]];
                                } else {
                                    NSMutableArray *array = productJSON[WMAPIKeyProduct];
                                    NSMutableArray *productArray = [[[WMNetworkUtility sharedInstance] currentProductArray] mutableCopy];
                                    [productArray addObjectsFromArray:array];

                                    [[WMNetworkUtility sharedInstance] setCurrentProductArray:productArray];
                                }

                                weakSelf.currentPage = [productJSON[WMAPIKeyPageNumber] integerValue];
                                weakSelf.totalItems = [productJSON[WMAPIKeyTotalProducts] integerValue];
                                
                                dispatch_async(dispatch_get_main_queue(), ^{
                                    [weakSelf.collectionView reloadData];
                                });
                                
                            }
                        }
                        
                    }
                }];
    
    [dataTask resume];
    
}

- (void)animateRefreshView
{
    // Background color to loop through for our color view
    NSArray *colorArray = @[[UIColor redColor],[UIColor blueColor],[UIColor purpleColor],[UIColor cyanColor],[UIColor orangeColor],[UIColor magentaColor]];
    static int colorIndex = 0;

    // Flag that we are animating
    self.isRefreshAnimating = YES;
    __weak __typeof(self) weakSelf = self;

    [UIView animateWithDuration:0.3
                          delay:0
                        options:UIViewAnimationOptionCurveLinear
                     animations:^{
                         // Rotate the spinner by M_PI_2 = PI/2 = 90 degrees
                         [weakSelf.compass_spinner setTransform:CGAffineTransformRotate(weakSelf.compass_spinner.transform, M_PI_2)];

                         // Change the background color
                         weakSelf.refreshColorView.backgroundColor = [colorArray objectAtIndex:colorIndex];
                         colorIndex = (colorIndex + 1) % colorArray.count;
                     }
                     completion:^(BOOL finished) {
                         // If still refreshing, keep spinning, else reset
                         if (weakSelf.refreshControl.isRefreshing) {
                             [weakSelf animateRefreshView];
                         }else{
                             [weakSelf resetAnimation];
                         }
                     }];
}

- (void)resetAnimation
{
    // Reset our flags and background color
    self.isRefreshAnimating = NO;
    self.isRefreshIconsOverlap = NO;
    self.refreshColorView.backgroundColor = [UIColor clearColor];
}

#pragma mark <UICollectionViewDataSource>

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {

    if (self.totalItems == [[[WMNetworkUtility sharedInstance] currentProductArray] count]) {
        return [[[WMNetworkUtility sharedInstance] currentProductArray] count];
    }
    return [[[WMNetworkUtility sharedInstance] currentProductArray] count] + 1;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {

    WMProductCollectionViewCell *cell = nil;

    if (indexPath.row == [[[WMNetworkUtility sharedInstance] currentProductArray] count]) {

        cell = [collectionView dequeueReusableCellWithReuseIdentifier:WMCollectionViewCellIdentifier forIndexPath:indexPath];
        UIActivityIndicatorView *activityIndicator = (UIActivityIndicatorView *)[cell.contentView viewWithTag:100];
        [activityIndicator startAnimating];

    } else {

    cell = [collectionView dequeueReusableCellWithReuseIdentifier:WMCollectionViewCellIdentifier forIndexPath:indexPath];
        NSDictionary *productDict = [[[WMNetworkUtility sharedInstance] currentProductArray] objectAtIndex:indexPath.row];
        cell.label.text = [productDict objectForKey:WMAPIKeyProductName];
        cell.priceLabel.text = [productDict objectForKey:WMAPIKeyPrice];
        [cell setupRatingViewWithRating:[[productDict objectForKey:WMAPIKeyRating] intValue] andCount:[[productDict objectForKey:WMAPIKeyCount] intValue]];
        if ([[productDict objectForKey:WMAPIKeyInStock] boolValue]) {
            cell.inStockLabel.text = @"In stock";
        } else {
            cell.inStockLabel.text = @"Not in stock";
        }
        NSURLSessionDownloadTask *getImageTask =
        [self.session downloadTaskWithURL:[NSURL URLWithString:[productDict objectForKey:WMAPIKeyProductImage]]

                   completionHandler:^(NSURL *location,
                                       NSURLResponse *response,
                                       NSError *error) {

                       UIImage *downloadedImage =
                       [UIImage imageWithData:
                        [NSData dataWithContentsOfURL:location]];

                       dispatch_async(dispatch_get_main_queue(), ^{
                           // do stuff with image
                           WMProductCollectionViewCell *updateCell = (id)[collectionView cellForItemAtIndexPath:indexPath];
                           if (updateCell) {
                               updateCell.imageView.image = downloadedImage;
                               NSArray *prodctArray = [[WMNetworkUtility sharedInstance] currentProductArray];
                               NSMutableDictionary *mutableDict = [[prodctArray objectAtIndex:indexPath.row] mutableCopy];
                               [mutableDict setObject:downloadedImage forKey:WMAPIKeyImageFile];
                               NSMutableArray *mutableArray = [prodctArray mutableCopy];
                               [mutableArray replaceObjectAtIndex:indexPath.row withObject:mutableDict];                                    [[WMNetworkUtility sharedInstance] setCurrentProductArray:mutableArray];
                           }

                       });
                   }];

        [getImageTask resume];
    }

    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView willDisplayCell:(UICollectionViewCell *)cell forItemAtIndexPath:(NSIndexPath *)indexPath
{
    if ([[[WMNetworkUtility sharedInstance] currentProductArray] count] != self.totalItems && indexPath.row == [[[WMNetworkUtility sharedInstance] currentProductArray] count] - 1 ) {
        [self renderProducts:++self.currentPage];
    }
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    WNProductDetailViewController *productViewController = [storyBoard instantiateViewControllerWithIdentifier:@"productDetail"];
    productViewController.modalPresentationStyle = UIModalPresentationFormSheet;
    productViewController.index = indexPath.row;
    UINavigationController	*navController = [[UINavigationController alloc] initWithRootViewController:productViewController];

    [self presentViewController:navController animated:YES completion:nil];
}

@end
