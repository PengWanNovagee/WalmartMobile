//
//  WMDescriptionTableViewCell.h
//  Walmart Mobile
//
//  Created by Wan, peng on 11/8/15.
//  Copyright © 2015 Wan, peng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WMDescriptionTableViewCell : UITableViewCell

@property (nonatomic, weak) IBOutlet UILabel *descriptionLabel;

- (CGFloat)heightForCellWithDescription:(NSAttributedString *)description;

@end
