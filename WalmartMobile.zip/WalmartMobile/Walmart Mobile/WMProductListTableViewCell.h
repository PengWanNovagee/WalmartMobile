//
//  WMProductListTableViewCell.h
//  Walmart Mobile
//
//  Created by Wan, peng on 11/8/15.
//  Copyright © 2015 Wan, peng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "StarRatingView.h"

@interface WMProductListTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *productNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *priceLabel;
@property (weak, nonatomic) IBOutlet UIImageView *productImageView;
@property (weak, nonatomic) IBOutlet StarRatingView *ratingView;
@property (assign, nonatomic) NSInteger rating;
@property (assign, nonatomic) NSInteger count;

- (void)setupRatingViewWithRating:(NSInteger)rating andCount:(NSInteger)count;
@end
