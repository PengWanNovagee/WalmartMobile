//
//  AppDelegate.h
//  Walmart Mobile
//
//  Created by Wan, peng on 11/6/15.
//  Copyright © 2015 Wan, peng. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

